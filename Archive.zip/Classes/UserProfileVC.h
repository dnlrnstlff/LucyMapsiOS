//
//  UserProfileVC.h
//  LUCY MAP FRAMEWORK
//
//  Created by Daniel-Ernest Luff.
//

#import <Foundation/Foundation.h>


@interface UserProfileVC : UIViewController {
    IBOutlet UILabel *Label; }

@property (retain, nonatomic) IBOutlet UILabel *Label;

@end
